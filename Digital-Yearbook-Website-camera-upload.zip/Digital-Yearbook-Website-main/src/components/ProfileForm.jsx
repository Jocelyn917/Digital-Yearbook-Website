import { Camera, Save, Upload } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

const blankProfile = {
  name: '',
  gradYear: '2026',
  photo: '',
  bio: '',
  memory: '',
  email: '',
  note: '',
};

export default function ProfileForm({ editingProfile, onSubmit, onCancel }) {
  const [form, setForm] = useState(blankProfile);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const videoRef = useRef(null);
  const streamRef = useRef(null);

  useEffect(() => {
    setForm(editingProfile || blankProfile);
  }, [editingProfile]);

  useEffect(() => {
    return () => stopCamera();
  }, []);

  function updateField(field, value) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  function handlePhotoUpload(event) {
    const file = event.target.files?.[0];
    if (!file || !file.type.startsWith('image/')) return;

    const reader = new FileReader();
    reader.onload = () => updateField('photo', reader.result);
    reader.readAsDataURL(file);
    event.target.value = '';
  }

  async function startCamera() {
    setCameraError('');

    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError('Camera access is not supported in this browser. Try uploading a photo instead.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      streamRef.current = stream;
      setCameraOpen(true);

      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
      }, 0);
    } catch (error) {
      setCameraError('Camera access was blocked or unavailable. Please allow camera permission or upload a photo.');
    }
  }

  function stopCamera() {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    setCameraOpen(false);
  }

  function capturePhoto() {
    if (!videoRef.current) return;

    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    const context = canvas.getContext('2d');
    if (!context) return;

    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    updateField('photo', canvas.toDataURL('image/png'));
    stopCamera();
  }

  function clearPhoto() {
    updateField('photo', '');
  }

  function handleSubmit(event) {
    event.preventDefault();
    onSubmit({
      ...form,
      photo: form.photo || `https://api.dicebear.com/9.x/initials/svg?seed=${encodeURIComponent(form.name || 'Yearbook')}`,
    });
    setForm(blankProfile);
    stopCamera();
  }

  return (
    <form className="panel form-grid" onSubmit={handleSubmit}>
      <div className="section-heading wide">
        <p className="eyebrow">Profiles</p>
        <h2>{editingProfile ? 'Edit classmate' : 'Add a classmate'}</h2>
      </div>
      <label>Name<input value={form.name} onChange={(event) => updateField('name', event.target.value)} required /></label>
      <label>Graduation year<input value={form.gradYear} onChange={(event) => updateField('gradYear', event.target.value)} required /></label>

      <div className="photo-picker wide">
        <label>Photo/avatar URL<input value={form.photo.startsWith('data:image') ? '' : form.photo} onChange={(event) => updateField('photo', event.target.value)} placeholder="Paste an image URL, upload one, or take a photo" /></label>
        <div className="photo-picker-actions">
          <label className="ghost-button upload-photo-button">
            <Upload size={18} /> Upload photo
            <input type="file" accept="image/*" onChange={handlePhotoUpload} hidden />
          </label>
          <button type="button" className="ghost-button" onClick={startCamera}><Camera size={18} /> Take photo</button>
          {form.photo && <button type="button" className="ghost-button" onClick={clearPhoto}>Remove photo</button>}
        </div>
        {cameraError && <p className="photo-error">{cameraError}</p>}
        {form.photo && <img className="profile-photo-preview" src={form.photo} alt="Selected profile preview" />}
      </div>

      <label className="wide">Bio<textarea value={form.bio} onChange={(event) => updateField('bio', event.target.value)} required /></label>
      <label className="wide">Favorite memory<textarea value={form.memory} onChange={(event) => updateField('memory', event.target.value)} required /></label>
      <label>Email/contact<input type="email" value={form.email} onChange={(event) => updateField('email', event.target.value)} required /></label>
      <label>Optional note<input value={form.note || ''} onChange={(event) => updateField('note', event.target.value)} /></label>
      <div className="form-actions wide">
        {editingProfile && <button type="button" className="ghost-button" onClick={onCancel}>Cancel</button>}
        <button className="primary-button" type="submit"><Save size={18} />{editingProfile ? 'Save profile' : 'Create profile'}</button>
      </div>

      {cameraOpen && (
        <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="Take profile photo">
          <div className="camera-panel panel">
            <div className="section-heading">
              <p className="eyebrow">Camera</p>
              <h2>Take a profile photo</h2>
            </div>
            <video ref={videoRef} autoPlay playsInline muted className="camera-preview" />
            <div className="form-actions">
              <button type="button" className="ghost-button" onClick={stopCamera}>Cancel</button>
              <button type="button" className="primary-button" onClick={capturePhoto}><Camera size={18} /> Capture photo</button>
            </div>
          </div>
        </div>
      )}
    </form>
  );
}
